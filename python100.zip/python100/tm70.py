'''
题目：写一个函数，求一个字符串的长度，在main函数中输入字符串，并输出其长度。
'''
s=input("please input a string:")
print(len(s))