#题目：数字比较。
a=10
b=20
print(a>b)