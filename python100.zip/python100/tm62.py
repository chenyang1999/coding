'''
题目：查找字符串。
'''
sStr1 = 'abcdefg'
sStr2 = 'cde'
print (sStr1.find(sStr2))