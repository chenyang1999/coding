'''
题目：计算字符串长度。　
'''
a=input()
print(len(a))