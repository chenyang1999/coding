'''
题目：字符串排序。
'''
sstr=[]
for i in range(3):
	x=input(f'{i}: ')
	sstr.append(x)
sstr.sort()
print(sstr)
	