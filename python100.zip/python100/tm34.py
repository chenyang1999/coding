'''
题目：练习函数调用。
'''
def fn():
	print("FUCK")
	return 
fn()