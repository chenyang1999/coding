'''
题目：循环输出列表
'''
s = ["man","woman","girl","boy","sister"]
for i in range(len(s)):
	print (s[i])