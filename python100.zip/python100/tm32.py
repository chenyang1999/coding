#题目：按相反的顺序输出列表的值。
a = ['one', 'two', 'three']
a.reverse()
print(a)