#题目：将一个数组逆序输出。
a=[9,6,5,4,1]
a.reverse()
print(a)