a=list(range(10))
print(a)
a.reverse()
print(a)