#题目：两个变量值互换。
a,b=1,2
a,b=b,a
print(a,b)