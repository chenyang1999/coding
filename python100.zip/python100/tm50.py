'''
题目：输出一个随机数。

程序分析：使用 random 模块。
'''
import random
 
#生成 10 到 20 之间的随机数
print (random.uniform(10, 20))
print(random.gauss(0,1))