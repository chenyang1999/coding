'''
题目：两个字符串连接程序。
'''
if __name__ == '__main__':
	a = "acegikm"
	b = "bdfhjlnpq"
 
	# 连接字符串
	c = a + b
	print (c)