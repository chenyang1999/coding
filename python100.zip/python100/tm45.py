'''
题目：统计 1 到 100 之和。
'''
print(sum(range(101)))