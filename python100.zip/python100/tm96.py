'''
题目：计算字符串中子串出现的次数。
'''
str1=input()
str2=input()
count=str1.count(str2)
print(count)